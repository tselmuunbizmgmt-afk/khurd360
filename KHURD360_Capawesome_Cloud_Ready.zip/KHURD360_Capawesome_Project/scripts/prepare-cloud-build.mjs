/**
 * Capawesome Cloud invokes `npm run build` after installing npm dependencies.
 * Since this project is supplied without platform templates, initialize the
 * official Capacitor Android & iOS templates on the cloud build runner.
 * Keeps the ZIP small; all templates come from official @capacitor packages.
 */
import { existsSync, mkdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
const root=join(dirname(fileURLToPath(import.meta.url)),'..');
const requested = process.argv[2];
const targets = requested==='android'||requested==='ios' ? [requested] : ['android','ios'];
const isWindows = process.platform === 'win32';
const exe=(name)=>join(root,'node_modules','.bin',name+(isWindows?'.cmd':''));
function run(cmd,args){
  console.log(`\n[khurd360] ${cmd} ${args.join(' ')}`);
  const r=spawnSync(cmd,args,{cwd:root,stdio:'inherit',shell:isWindows});
  if(r.error){console.error(r.error);process.exit(1);}
  if(r.status!==0){console.error(`[khurd360] command failed (${r.status}): ${cmd}`);process.exit(r.status||1);}
}
for(const f of ['www/index.html','www/styles.css','www/app.js','capacitor.config.json']){
  if(!existsSync(join(root,f))){console.error(`[khurd360] missing required file: ${f}`);process.exit(1);}
}
if(!existsSync(exe('cap'))){
 console.error('[khurd360] Capacitor CLI missing. Run npm install before this build.');process.exit(1);
}
for(const platform of targets){
  const marker=platform==='android' ? 'android/app/build.gradle':'ios/App/App.xcodeproj/project.pbxproj';
  if(!existsSync(join(root,marker))){
    console.log(`[khurd360] generating official ${platform} native project`);
    run(exe('cap'),['add',platform]);
  } else console.log(`[khurd360] found ${platform} native project`);
  run(exe('cap'),['sync',platform]);
}
if(existsSync(exe('capacitor-assets'))){
  console.log('[khurd360] generating app icons and splash screens');
  run(exe('capacitor-assets'),['generate', ...targets.map(t=>'--'+t),'--iconBackgroundColor','#F4F7FC','--splashBackgroundColor','#F4F7FC']);
}
console.log('[khurd360] native projects and web assets are ready for cloud compilation');

# KHURD 360 — CAPAWESOME CLOUD MOBILE APP PROJECT

A Capacitor 8 source project, converted from the latest KHURD 360 blue/white prototype.
**This is not a Netlify project.** It is source code for building an Android APK/AAB and iOS IPA with Capawesome Cloud.

## INCLUDED
- `www/` — complete offline-capable static app UI: projects, charts, filters, tax-footprint estimator, watchlist, dark mode, EN/MN language switch, `by hannu co.` branding.
- `capacitor.config.json` — app name KHURD 360, application ID `co.hannu.khurd360`, native web asset directory `www`.
- `package.json` — Capacitor dependencies and cloud build script.
- `scripts/prepare-cloud-build.mjs` — creates official Android/iOS native projects using Capacitor CLI *on the build machine* and syncs web assets.
- `assets/icon.png`, `assets/splash.png` — branded source images for native icons and splash screens.
- No Netlify settings, hosted URL, bank connections or government account credentials.

## SIMPLEST: CAPAWESOME CLOUD + GITHUB (NO LOCAL MAC)
1. Extract this ZIP. In GitHub, create a new repository and upload the **contents** of `KHURD360_Capawesome_Project`, with `package.json` at repository root. Do not commit another enclosing folder.
2. Create a Capawesome Cloud account at https://console.cloud.capawesome.io/.
3. Create app `KHURD 360` and connect your GitHub repository.
4. Trigger an **Android Debug** native build for your main branch. The build runner's `npm run build` generates the native platform templates and syncs the existing `www` app. Download the APK from successful builds.
5. For iOS, trigger an **iOS Simulator** build for testing (simulator-only). To install on an actual iPhone or publish to the App Store, you'll need an Apple developer account and correct signing credentials/certificates.
6. Android production needs a release signing certificate and Google Play developer account.

## NO GITHUB: CAPAWESOME CLI DIRECT UPLOAD
Requires Node.js 22+ and a Capawesome Cloud account (no Mac required for the remote build):
```
cd KHURD360_Capawesome_Project
npm install
npx @capawesome/cli login
npx @capawesome/cli apps:create
npx @capawesome/cli apps:builds:create --app-id YOUR_CAPAWESOME_APP_ID --path . --platform android --type debug
```
For iOS Simulator builds use `--platform ios --type simulator` instead. Replace the cloud app ID with your ID from the Capawesome console.
See https://capawesome.io/docs/cloud/native-builds/build-without-git/ for `--path` support.

## LOCAL SOURCE CHECK
```
node scripts/validate-project.mjs
```

## LOCAL PROJECT CREATION (OPTIONAL)
After `npm install`, use `npm run native:android`, `npm run native:ios`, or `npm run build` to generate native projects from official Capacitor packages. This may require local Android Studio, Xcode/CocoaPods on the developer computer; cloud builds do not require you to own a Mac. Commit generated `android/` and `ios/` directories if your Cloud workflow requires native projects already in Git.

## PRIVACY AND DATA
This is an **interactive prototype**, NOT a live government-data service. Every budget figure, project, and tax-footprint example is fictional/illustrative. Local browser storage keeps UI preferences/bookmarks. No bank account, E-Mongolia or tax service integration is implemented. External government links require internet access. Do not present demo values as real data.

## CAVEATS
- The original HTML/CSS/JS functionality has been kept; service-worker registration was removed for the native webview to avoid stale cached updates.
- Native APK/IPA builds and App Store approval have NOT been verified in this authoring environment; npm packages/network and a cloud signing account are needed to complete an actual build.
- App identifier `co.hannu.khurd360` is provisional: verify you control it before publishing and keep it stable once you release.
- The app will need production data, a privacy policy, and additional functionality/QA before any public store release. Apple's guidelines can reject apps that merely wrap a website or lack sufficient native value.

Official documentation:
https://capawesome.io/docs/cloud/native-builds/setup/
https://capacitorjs.com/docs/getting-started
